create table public.tags (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  type        text not null check (type in ('income', 'expense')),
  name        text not null check (char_length(btrim(name)) between 1 and 20),
  colour      text not null,
  is_default  boolean not null default false,
  is_others   boolean not null default false,
  created_at  timestamptz not null default now()
);


create unique index tags_user_type_lower_name_uq
  on public.tags (user_id, type, lower(btrim(name)));


create unique index tags_one_others_per_type
  on public.tags (user_id, type)
  where is_others;


create or replace function public.enforce_tag_limit()
returns trigger as $$
declare
  tag_count integer;
begin

  perform pg_advisory_xact_lock(
    hashtext(new.user_id::text || ':' || new.type::text)
  );

  select count(*) into tag_count
  from public.tags
  where user_id = new.user_id
    and type = new.type;

  if tag_count >= 100 then
    raise exception 'Tag limit reached: maximum 100 tags allowed per type'
      using errcode = 'check_violation';
  end if;

  return new;
end;
$$ language plpgsql;

create trigger trg_enforce_tag_limit
  before insert on public.tags
  for each row
  execute function public.enforce_tag_limit();
  -- Step 6: Protect the "Others" tag from rename / delete
create or replace function public.protect_others_tag()
returns trigger as $$
begin
  if old.is_others then

    if tg_op = 'DELETE' then
      -- Allow cascade deletes (when a whole user account is deleted)
      if pg_trigger_depth() > 1 then
        return old;
      end if;
      raise exception 'The Others tag cannot be deleted'
        using errcode = 'check_violation';
    end if;

    -- UPDATE: block changes to name, type, flag, owner
    if new.name is distinct from old.name
       or new.type is distinct from old.type
       or new.is_others is distinct from old.is_others
       or new.user_id is distinct from old.user_id then
      raise exception 'The Others tag cannot be renamed or modified'
        using errcode = 'check_violation';
    end if;

  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_protect_others_tag
  before update or delete on public.tags
  for each row
  execute function public.protect_others_tag();
  grant select, insert, update, delete on public.tags to authenticated;
grant all on public.tags to service_role;

  -- Step 7: Row Level Security
alter table public.tags enable row level security;

create policy "tags_select_own"
  on public.tags for select
  to authenticated
  using (user_id = (select auth.uid()));

create policy "tags_insert_own"
  on public.tags for insert
  to authenticated
  with check (user_id = (select auth.uid()));

create policy "tags_update_own"
  on public.tags for update
  to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy "tags_delete_own"
  on public.tags for delete
  to authenticated
  using (user_id = (select auth.uid()));
  
